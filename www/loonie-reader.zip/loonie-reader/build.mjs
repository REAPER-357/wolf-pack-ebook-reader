// Run once:  npm install && npm run setup
// Copies the JS libraries into assets/libs and compiles Tailwind into assets/css/tailwind.css
import { copyFileSync, mkdirSync, existsSync } from 'node:fs';
import { execSync } from 'node:child_process';

const libs = [
  ['node_modules/pdfjs-dist/build/pdf.min.js', 'assets/libs/pdf.min.js'],
  ['node_modules/pdfjs-dist/build/pdf.worker.min.js', 'assets/libs/pdf.worker.min.js'],
  ['node_modules/jszip/dist/jszip.min.js', 'assets/libs/jszip.min.js'],
  ['node_modules/mammoth/mammoth.browser.min.js', 'assets/libs/mammoth.browser.min.js'],
];

mkdirSync('assets/libs', { recursive: true });
mkdirSync('assets/css', { recursive: true });

for (const [from, to] of libs) {
  if (!existsSync(from)) {
    console.error('Missing ' + from + ' - run "npm install" first.');
    process.exit(1);
  }
  copyFileSync(from, to);
  console.log('copied  ' + to);
}

execSync('npx tailwindcss -c tailwind.config.js -i src/input.css -o assets/css/tailwind.css --minify', { stdio: 'inherit' });
console.log('built   assets/css/tailwind.css');
console.log('Done. Add your icons to assets/icons/ (see README.txt), then serve the folder over http.');
